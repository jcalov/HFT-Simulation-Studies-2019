complete <-
function(x)subset(x,complete.cases(x))

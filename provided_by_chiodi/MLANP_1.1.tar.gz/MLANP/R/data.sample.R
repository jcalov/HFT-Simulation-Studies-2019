data.sample <-
function(x,k=1){x=as.data.frame(x)
return(x[sample(nrow(x),k),])
}

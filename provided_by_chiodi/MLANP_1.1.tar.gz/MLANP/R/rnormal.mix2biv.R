# RANDOM NORMALMIX2
 #    rmvnorm.mixt(n=100, mus=c(0,0), Sigmas=diag(2), props=1, mixt.label=FALSE)
rnormal.mix2biv<-function(n=100,mean=rbind(c(0,0),c(2,2)),sd=rbind(c(1,1),c(1,1)),r=c(0,0),p=0.5){
ind<-2-as.numeric(runif(n)<p)
vx=sd[1,1]
vy=sd[1,2]
sig1=rbind(c(vx^2,vx*vy*r[1]),c(vx*vy*r[1],vy^2))
vx=sd[2,1]
vy=sd[2,2]
sig2=rbind(c(vx^2,vx*vy*r[2]),c(vx*vy*r[2],vy^2))
x=rmvnorm.mixt(n, props=c(p,1-p), mus=mean,  Sigma=rbind(sig1,sig2))
return(x)
}

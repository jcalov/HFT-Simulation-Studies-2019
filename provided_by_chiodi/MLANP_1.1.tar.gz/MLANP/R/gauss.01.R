#
#

## to be checked 3-2-2019
## read gaussian coeff. in -1,1 and converts in 0-1 quadrature formulas
## returns points and weights for quadrature with 2^igauss points
##

gauss.01	<-function(igauss){
#coeff1.128<-scan("gaussian1-128.txt",sep=",")
data(gaussian1_128)


	xg=matrix(0,256,9)
	
	wg=matrix(0,256,9)
 	
	xg[1,1]=0.5
	wg[1,1]=1
	print("letti coeff.gaussiani")
	for(i in 1:8){
			j	<-	i+1

	xg[1:(2^(i-1)),j]	<-	(1-gaussian1_128[(2^(i-1)):(2^i-1)])/2
	xg[(2^(i-1)+1):(2^i),j]	<-	1-xg[(2^(i-1)):1,j]

	wg[1:(2^(i-1)),j]	<-	gaussian1_128[255+(2^(i-1)):(2^i-1)]/2
	wg[(2^(i-1)+1):(2^i),j]	<-	wg[(2^(i-1)):1,j]
	
	}
	print("rielaborati coeff.gaussiani")

 xl=list(xg[1:1,1],xg[1:2,2],xg[1:4,3],xg[1:8,4],xg[1:16,5],xg[1:32,6],xg[1:64,7],xg[1:128,8],xg[1:256,9])

 wl=list(wg[1:1,1],wg[1:2,2],wg[1:4,3],wg[1:8,4],wg[1:16,5],wg[1:32,6],wg[1:64,7],wg[1:128,8],wg[1:256,9])

	print("calcolate liste con coeff.gaussiani")
		return(list(x=xl[[igauss+1]],w=wl[[igauss+1]]))
			}


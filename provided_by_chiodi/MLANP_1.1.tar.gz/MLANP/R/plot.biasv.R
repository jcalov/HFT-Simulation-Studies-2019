
## plot unico
plot.biasv= function(x,...){
f=x
par(mfrow=c(1,2))
bias=(f$m-f$true)
v=f$s^2
plot(diff(diff(f$true)),bias[-c(1,100)])
l=lm(bias[-c(1,100)]~diff(diff(f$true)))
abline(l)
plot(f$true,v)
l=lm(v ~  f$true)
abline(l)
}


stand.01 <-
function(x)(x-min(x))/diff(range(x))

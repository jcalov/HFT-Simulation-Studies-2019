order.var <-
function(data,var="V1")data[order(as.vector(data[[var]])),]

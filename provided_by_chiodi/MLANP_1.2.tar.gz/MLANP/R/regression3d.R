# visualization of a multiple linear regression with confidence
# region for expected value  E(y)=beta0+beta1*x1+beta2*x2
# and for future observation
# input is a matrix with x1,x2 and y

regression3d=function(graf1,ext=0.3,newplot=TRUE,points=TRUE,conf.exp=TRUE,conf.sing=FALSE,level=0.95, ell=FALSE,liv.ell=0.2){
library(rgl)
library(misc3d)

#plot3d(graf1[,1:3])
if (newplot) plot3d(graf1[,1:3])
if(points) points3d(graf1[,1:3])
dat=as.data.frame(graf1)
names(dat)=c("x1","x2","y")
p1=lm(y~x1+x2,data=dat)

if(points) points3d(dat$x1,dat$x2,p1$fitted,col="red")


r1=diff(range(dat$x1))*ext
r2=diff(range(dat$x2))*ext


teo=as.data.frame(xy.grid(c(min(dat$x1)-r1,max(dat$x1)+r1),c(min(dat$x2)-r2,max(dat$x2)+r2),nx=20))
names(teo)=c("x1","x2")
pr1=predict.lm(p1,newdata=teo,se.f=TRUE,level=level,interval="confidence")


surface3d(unique(teo[,1]),unique(teo[,2]),pr1$fit[,1],alpha=0.8,color="red",fog=F,fron="line",back="line",col="black")

scal.col=(pr1$se.fit/max(pr1$se.fit))^2


if(conf.exp) {
surface3d(unique(teo[,1 ]),unique(teo[,2]),pr1$fit[,2],alpha=0.4,col=rgb(scal.col,0,0))
surface3d(unique(teo[,1 ]),unique(teo[,2]),pr1$fit[,3],alpha=0.4,col=rgb(scal.col,0,0))
}
if(conf.sing) {
pr1=predict.lm(p1,newdata=teo,se.f=TRUE,level=level,interval="prediction")
surface3d(unique(teo[,1 ]),unique(teo[,2]),pr1$fit[,2],alpha=0.2,col=rgb(0,scal.col,0))
surface3d(unique(teo[,1 ]),unique(teo[,2]),pr1$fit[,3],alpha=0.2,col=rgb(0,scal.col,0))
}
if (ell){
diff=pr1$fit[,1]-pr1$fit[,2]
liv=min(diff)+range(diff)*liv.ell
print( rgb(diff<liv,0,0)   )
surface3d(unique(teo[,1 ]),unique(teo[,2]),pr1$fit[,3],alpha=1,col=rgb(diff<liv,0,0))
}
#play3d(spin3d(axis=c(0,0,1), rpm=4), duration=15)

}
